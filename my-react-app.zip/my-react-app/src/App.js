import "./App.css";
import PostList from "./PostList";

function App() {
  return (
    <div className="App">
      <PostList />
    </div>
  );
}

export default App;
